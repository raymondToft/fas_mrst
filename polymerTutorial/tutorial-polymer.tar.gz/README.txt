In the comments of the MATLAB files, the words starting with 'perl' (such as perlAddLink,
perlOneLineDescription, ...) should be ignored. They are used when automatically setting up the web
version of the tutorial.
